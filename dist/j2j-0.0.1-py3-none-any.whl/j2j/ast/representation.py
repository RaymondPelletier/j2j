from dataclasses import dataclass, field
from typing      import Dict, List, Union

@dataclass
class Variable:
    identifier: str
    anonymous:  bool = field(init=False, default=False)
    #
    anon_counter = 0

    def __post_init__(self):
        if self.identifier == '_':
            Variable.anon_counter += 1
            self.anonymous = True
            self.identifier = f'$_{Variable.anon_counter}'

    def __repr__(self):
        return self.identifier if not self.anonymous else '_'

@dataclass
class VarArgs:
    variable: Variable

## Used by emitter to identify KWArgs in a dictionary
class KWArgs:
    def __repr__(self):
        return '<KWArgs>'

Template = Union[List, Dict, str, int, float, bool, type(None)]

@dataclass
class Transform:
    input:  Template
    output: Template

@dataclass
class Matcher:
    variable: Variable
    template: Template

@dataclass
class Assignment:
    variable: Variable
    template: Template

@dataclass
class Join:
    matchers:    List[Matcher]
    assignments: List[Assignment]
