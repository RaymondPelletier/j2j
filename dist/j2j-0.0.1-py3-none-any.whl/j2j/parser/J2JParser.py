# Generated from J2J.g4 by ANTLR 4.11.1
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,20,115,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,
        6,2,7,7,7,2,8,7,8,2,9,7,9,2,10,7,10,2,11,7,11,2,12,7,12,2,13,7,13,
        1,0,1,0,1,0,1,0,1,1,4,1,34,8,1,11,1,12,1,35,1,2,4,2,39,8,2,11,2,
        12,2,40,1,2,1,2,4,2,45,8,2,11,2,12,2,46,1,3,1,3,1,3,1,3,1,4,1,4,
        1,4,1,4,1,5,1,5,1,5,1,5,3,5,61,8,5,1,6,1,6,1,6,1,6,5,6,67,8,6,10,
        6,12,6,70,9,6,1,6,1,6,3,6,74,8,6,1,6,1,6,1,6,1,6,3,6,80,8,6,1,7,
        1,7,1,7,1,7,1,8,1,8,1,8,1,9,1,9,1,9,1,9,5,9,93,8,9,10,9,12,9,96,
        9,9,1,9,1,9,1,9,1,9,3,9,102,8,9,1,10,1,10,3,10,106,8,10,1,11,1,11,
        1,11,1,12,1,12,1,13,1,13,1,13,0,0,14,0,2,4,6,8,10,12,14,16,18,20,
        22,24,26,0,1,2,0,10,13,17,18,112,0,28,1,0,0,0,2,33,1,0,0,0,4,38,
        1,0,0,0,6,48,1,0,0,0,8,52,1,0,0,0,10,60,1,0,0,0,12,79,1,0,0,0,14,
        81,1,0,0,0,16,85,1,0,0,0,18,101,1,0,0,0,20,105,1,0,0,0,22,107,1,
        0,0,0,24,110,1,0,0,0,26,112,1,0,0,0,28,29,3,10,5,0,29,30,5,9,0,0,
        30,31,3,10,5,0,31,1,1,0,0,0,32,34,3,6,3,0,33,32,1,0,0,0,34,35,1,
        0,0,0,35,33,1,0,0,0,35,36,1,0,0,0,36,3,1,0,0,0,37,39,3,6,3,0,38,
        37,1,0,0,0,39,40,1,0,0,0,40,38,1,0,0,0,40,41,1,0,0,0,41,42,1,0,0,
        0,42,44,5,9,0,0,43,45,3,8,4,0,44,43,1,0,0,0,45,46,1,0,0,0,46,44,
        1,0,0,0,46,47,1,0,0,0,47,5,1,0,0,0,48,49,3,26,13,0,49,50,5,14,0,
        0,50,51,3,10,5,0,51,7,1,0,0,0,52,53,3,26,13,0,53,54,5,15,0,0,54,
        55,3,10,5,0,55,9,1,0,0,0,56,61,3,12,6,0,57,61,3,18,9,0,58,61,3,24,
        12,0,59,61,3,26,13,0,60,56,1,0,0,0,60,57,1,0,0,0,60,58,1,0,0,0,60,
        59,1,0,0,0,61,11,1,0,0,0,62,63,5,1,0,0,63,68,3,14,7,0,64,65,5,2,
        0,0,65,67,3,14,7,0,66,64,1,0,0,0,67,70,1,0,0,0,68,66,1,0,0,0,68,
        69,1,0,0,0,69,73,1,0,0,0,70,68,1,0,0,0,71,72,5,2,0,0,72,74,3,16,
        8,0,73,71,1,0,0,0,73,74,1,0,0,0,74,75,1,0,0,0,75,76,5,3,0,0,76,80,
        1,0,0,0,77,78,5,1,0,0,78,80,5,3,0,0,79,62,1,0,0,0,79,77,1,0,0,0,
        80,13,1,0,0,0,81,82,5,13,0,0,82,83,5,4,0,0,83,84,3,10,5,0,84,15,
        1,0,0,0,85,86,5,5,0,0,86,87,3,26,13,0,87,17,1,0,0,0,88,89,5,6,0,
        0,89,94,3,20,10,0,90,91,5,2,0,0,91,93,3,20,10,0,92,90,1,0,0,0,93,
        96,1,0,0,0,94,92,1,0,0,0,94,95,1,0,0,0,95,97,1,0,0,0,96,94,1,0,0,
        0,97,98,5,7,0,0,98,102,1,0,0,0,99,100,5,6,0,0,100,102,5,7,0,0,101,
        88,1,0,0,0,101,99,1,0,0,0,102,19,1,0,0,0,103,106,3,10,5,0,104,106,
        3,22,11,0,105,103,1,0,0,0,105,104,1,0,0,0,106,21,1,0,0,0,107,108,
        5,8,0,0,108,109,3,26,13,0,109,23,1,0,0,0,110,111,7,0,0,0,111,25,
        1,0,0,0,112,113,5,16,0,0,113,27,1,0,0,0,10,35,40,46,60,68,73,79,
        94,101,105
    ]

class J2JParser ( Parser ):

    grammarFileName = "J2J.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'{'", "','", "'}'", "':'", "'**'", "'['", 
                     "']'", "'*'", "'-->'", "'null'", "'true'", "'false'", 
                     "<INVALID>", "'~'", "':='" ]

    symbolicNames = [ "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "IMPLIES", "NULL", "TRUE", "FALSE", "STRING", 
                      "MATCHES", "ASSIGNED", "IDENTIFIER", "INTEGER", "FLOAT", 
                      "WS", "LINE_COMMENT" ]

    RULE_transform = 0
    RULE_collate = 1
    RULE_join = 2
    RULE_matcher = 3
    RULE_assignment = 4
    RULE_template = 5
    RULE_obj = 6
    RULE_key_value = 7
    RULE_kwargs = 8
    RULE_array = 9
    RULE_element = 10
    RULE_varargs = 11
    RULE_atom = 12
    RULE_variable = 13

    ruleNames =  [ "transform", "collate", "join", "matcher", "assignment", 
                   "template", "obj", "key_value", "kwargs", "array", "element", 
                   "varargs", "atom", "variable" ]

    EOF = Token.EOF
    T__0=1
    T__1=2
    T__2=3
    T__3=4
    T__4=5
    T__5=6
    T__6=7
    T__7=8
    IMPLIES=9
    NULL=10
    TRUE=11
    FALSE=12
    STRING=13
    MATCHES=14
    ASSIGNED=15
    IDENTIFIER=16
    INTEGER=17
    FLOAT=18
    WS=19
    LINE_COMMENT=20

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.11.1")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class TransformContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def template(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(J2JParser.TemplateContext)
            else:
                return self.getTypedRuleContext(J2JParser.TemplateContext,i)


        def IMPLIES(self):
            return self.getToken(J2JParser.IMPLIES, 0)

        def getRuleIndex(self):
            return J2JParser.RULE_transform

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTransform" ):
                listener.enterTransform(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTransform" ):
                listener.exitTransform(self)




    def transform(self):

        localctx = J2JParser.TransformContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_transform)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 28
            self.template()
            self.state = 29
            self.match(J2JParser.IMPLIES)
            self.state = 30
            self.template()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class CollateContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def matcher(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(J2JParser.MatcherContext)
            else:
                return self.getTypedRuleContext(J2JParser.MatcherContext,i)


        def getRuleIndex(self):
            return J2JParser.RULE_collate

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCollate" ):
                listener.enterCollate(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCollate" ):
                listener.exitCollate(self)




    def collate(self):

        localctx = J2JParser.CollateContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_collate)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 33 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 32
                self.matcher()
                self.state = 35 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==16):
                    break

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class JoinContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IMPLIES(self):
            return self.getToken(J2JParser.IMPLIES, 0)

        def matcher(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(J2JParser.MatcherContext)
            else:
                return self.getTypedRuleContext(J2JParser.MatcherContext,i)


        def assignment(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(J2JParser.AssignmentContext)
            else:
                return self.getTypedRuleContext(J2JParser.AssignmentContext,i)


        def getRuleIndex(self):
            return J2JParser.RULE_join

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterJoin" ):
                listener.enterJoin(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitJoin" ):
                listener.exitJoin(self)




    def join(self):

        localctx = J2JParser.JoinContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_join)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 38 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 37
                self.matcher()
                self.state = 40 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==16):
                    break

            self.state = 42
            self.match(J2JParser.IMPLIES)
            self.state = 44 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 43
                self.assignment()
                self.state = 46 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==16):
                    break

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class MatcherContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def variable(self):
            return self.getTypedRuleContext(J2JParser.VariableContext,0)


        def MATCHES(self):
            return self.getToken(J2JParser.MATCHES, 0)

        def template(self):
            return self.getTypedRuleContext(J2JParser.TemplateContext,0)


        def getRuleIndex(self):
            return J2JParser.RULE_matcher

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMatcher" ):
                listener.enterMatcher(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMatcher" ):
                listener.exitMatcher(self)




    def matcher(self):

        localctx = J2JParser.MatcherContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_matcher)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 48
            self.variable()
            self.state = 49
            self.match(J2JParser.MATCHES)
            self.state = 50
            self.template()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AssignmentContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def variable(self):
            return self.getTypedRuleContext(J2JParser.VariableContext,0)


        def ASSIGNED(self):
            return self.getToken(J2JParser.ASSIGNED, 0)

        def template(self):
            return self.getTypedRuleContext(J2JParser.TemplateContext,0)


        def getRuleIndex(self):
            return J2JParser.RULE_assignment

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAssignment" ):
                listener.enterAssignment(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAssignment" ):
                listener.exitAssignment(self)




    def assignment(self):

        localctx = J2JParser.AssignmentContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_assignment)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 52
            self.variable()
            self.state = 53
            self.match(J2JParser.ASSIGNED)
            self.state = 54
            self.template()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TemplateContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def obj(self):
            return self.getTypedRuleContext(J2JParser.ObjContext,0)


        def array(self):
            return self.getTypedRuleContext(J2JParser.ArrayContext,0)


        def atom(self):
            return self.getTypedRuleContext(J2JParser.AtomContext,0)


        def variable(self):
            return self.getTypedRuleContext(J2JParser.VariableContext,0)


        def getRuleIndex(self):
            return J2JParser.RULE_template

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTemplate" ):
                listener.enterTemplate(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTemplate" ):
                listener.exitTemplate(self)




    def template(self):

        localctx = J2JParser.TemplateContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_template)
        try:
            self.state = 60
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [1]:
                self.enterOuterAlt(localctx, 1)
                self.state = 56
                self.obj()
                pass
            elif token in [6]:
                self.enterOuterAlt(localctx, 2)
                self.state = 57
                self.array()
                pass
            elif token in [10, 11, 12, 13, 17, 18]:
                self.enterOuterAlt(localctx, 3)
                self.state = 58
                self.atom()
                pass
            elif token in [16]:
                self.enterOuterAlt(localctx, 4)
                self.state = 59
                self.variable()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ObjContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self._key_value = None # Key_valueContext
            self.key_values = list() # of Key_valueContexts

        def key_value(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(J2JParser.Key_valueContext)
            else:
                return self.getTypedRuleContext(J2JParser.Key_valueContext,i)


        def kwargs(self):
            return self.getTypedRuleContext(J2JParser.KwargsContext,0)


        def getRuleIndex(self):
            return J2JParser.RULE_obj

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterObj" ):
                listener.enterObj(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitObj" ):
                listener.exitObj(self)




    def obj(self):

        localctx = J2JParser.ObjContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_obj)
        self._la = 0 # Token type
        try:
            self.state = 79
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,6,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 62
                self.match(J2JParser.T__0)
                self.state = 63
                localctx._key_value = self.key_value()
                localctx.key_values.append(localctx._key_value)
                self.state = 68
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,4,self._ctx)
                while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                    if _alt==1:
                        self.state = 64
                        self.match(J2JParser.T__1)
                        self.state = 65
                        localctx._key_value = self.key_value()
                        localctx.key_values.append(localctx._key_value) 
                    self.state = 70
                    self._errHandler.sync(self)
                    _alt = self._interp.adaptivePredict(self._input,4,self._ctx)

                self.state = 73
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==2:
                    self.state = 71
                    self.match(J2JParser.T__1)
                    self.state = 72
                    self.kwargs()


                self.state = 75
                self.match(J2JParser.T__2)
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 77
                self.match(J2JParser.T__0)
                self.state = 78
                self.match(J2JParser.T__2)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Key_valueContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def STRING(self):
            return self.getToken(J2JParser.STRING, 0)

        def template(self):
            return self.getTypedRuleContext(J2JParser.TemplateContext,0)


        def getRuleIndex(self):
            return J2JParser.RULE_key_value

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterKey_value" ):
                listener.enterKey_value(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitKey_value" ):
                listener.exitKey_value(self)




    def key_value(self):

        localctx = J2JParser.Key_valueContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_key_value)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 81
            self.match(J2JParser.STRING)
            self.state = 82
            self.match(J2JParser.T__3)
            self.state = 83
            self.template()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class KwargsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def variable(self):
            return self.getTypedRuleContext(J2JParser.VariableContext,0)


        def getRuleIndex(self):
            return J2JParser.RULE_kwargs

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterKwargs" ):
                listener.enterKwargs(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitKwargs" ):
                listener.exitKwargs(self)




    def kwargs(self):

        localctx = J2JParser.KwargsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_kwargs)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 85
            self.match(J2JParser.T__4)
            self.state = 86
            self.variable()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ArrayContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser
            self._element = None # ElementContext
            self.elements = list() # of ElementContexts

        def element(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(J2JParser.ElementContext)
            else:
                return self.getTypedRuleContext(J2JParser.ElementContext,i)


        def getRuleIndex(self):
            return J2JParser.RULE_array

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterArray" ):
                listener.enterArray(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitArray" ):
                listener.exitArray(self)




    def array(self):

        localctx = J2JParser.ArrayContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_array)
        self._la = 0 # Token type
        try:
            self.state = 101
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,8,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 88
                self.match(J2JParser.T__5)
                self.state = 89
                localctx._element = self.element()
                localctx.elements.append(localctx._element)
                self.state = 94
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==2:
                    self.state = 90
                    self.match(J2JParser.T__1)
                    self.state = 91
                    localctx._element = self.element()
                    localctx.elements.append(localctx._element)
                    self.state = 96
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                self.state = 97
                self.match(J2JParser.T__6)
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 99
                self.match(J2JParser.T__5)
                self.state = 100
                self.match(J2JParser.T__6)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ElementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def template(self):
            return self.getTypedRuleContext(J2JParser.TemplateContext,0)


        def varargs(self):
            return self.getTypedRuleContext(J2JParser.VarargsContext,0)


        def getRuleIndex(self):
            return J2JParser.RULE_element

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterElement" ):
                listener.enterElement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitElement" ):
                listener.exitElement(self)




    def element(self):

        localctx = J2JParser.ElementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_element)
        try:
            self.state = 105
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [1, 6, 10, 11, 12, 13, 16, 17, 18]:
                self.enterOuterAlt(localctx, 1)
                self.state = 103
                self.template()
                pass
            elif token in [8]:
                self.enterOuterAlt(localctx, 2)
                self.state = 104
                self.varargs()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class VarargsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def variable(self):
            return self.getTypedRuleContext(J2JParser.VariableContext,0)


        def getRuleIndex(self):
            return J2JParser.RULE_varargs

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterVarargs" ):
                listener.enterVarargs(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitVarargs" ):
                listener.exitVarargs(self)




    def varargs(self):

        localctx = J2JParser.VarargsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_varargs)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 107
            self.match(J2JParser.T__7)
            self.state = 108
            self.variable()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AtomContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def NULL(self):
            return self.getToken(J2JParser.NULL, 0)

        def TRUE(self):
            return self.getToken(J2JParser.TRUE, 0)

        def FALSE(self):
            return self.getToken(J2JParser.FALSE, 0)

        def INTEGER(self):
            return self.getToken(J2JParser.INTEGER, 0)

        def FLOAT(self):
            return self.getToken(J2JParser.FLOAT, 0)

        def STRING(self):
            return self.getToken(J2JParser.STRING, 0)

        def getRuleIndex(self):
            return J2JParser.RULE_atom

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAtom" ):
                listener.enterAtom(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAtom" ):
                listener.exitAtom(self)




    def atom(self):

        localctx = J2JParser.AtomContext(self, self._ctx, self.state)
        self.enterRule(localctx, 24, self.RULE_atom)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 110
            _la = self._input.LA(1)
            if not(((_la) & ~0x3f) == 0 and ((1 << _la) & 408576) != 0):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class VariableContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IDENTIFIER(self):
            return self.getToken(J2JParser.IDENTIFIER, 0)

        def getRuleIndex(self):
            return J2JParser.RULE_variable

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterVariable" ):
                listener.enterVariable(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitVariable" ):
                listener.exitVariable(self)




    def variable(self):

        localctx = J2JParser.VariableContext(self, self._ctx, self.state)
        self.enterRule(localctx, 26, self.RULE_variable)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 112
            self.match(J2JParser.IDENTIFIER)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx





