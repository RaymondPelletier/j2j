# j2j

[![PyPI - Version](https://img.shields.io/pypi/v/j2j.svg)](https://pypi.org/project/j2j)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/j2j.svg)](https://pypi.org/project/j2j)

-----

**Table of Contents**

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install j2j
```

## License

`j2j` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
