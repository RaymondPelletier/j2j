# j2j

A minimally viable Python package for processing structured data

-----

**Table of Contents**

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install j2j
```

## License

`j2j` is distributed under the terms of the [Apache-2.0](https://spdx.org/licenses/Apache-2.0.html) license.
