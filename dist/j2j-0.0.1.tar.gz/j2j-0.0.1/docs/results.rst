

Result Objects
==============

.. automodule:: j2j.results
   :members:
