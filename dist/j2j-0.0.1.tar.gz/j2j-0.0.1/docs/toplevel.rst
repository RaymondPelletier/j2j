
Toplevel functions
==================

Matching
^^^^^^^^
.. autofunction:: j2j.match
.. autofunction:: j2j.match_all
.. autofunction:: j2j.compile_match

Filling
^^^^^^^
.. autofunction:: j2j.fill
.. autofunction:: j2j.compile_fill

Transforming
^^^^^^^^^^^^
.. autofunction:: j2j.transform
.. autofunction:: j2j.transform_all
.. autofunction:: j2j.compile_transform

Collating
^^^^^^^^^
.. autofunction:: j2j.collate
.. autofunction:: j2j.collate_all
.. autofunction:: j2j.compile_collate

Inferring
^^^^^^^^^
.. autofunction:: j2j.infer
.. autofunction:: j2j.infer_all
.. autofunction:: j2j.compile_rule
