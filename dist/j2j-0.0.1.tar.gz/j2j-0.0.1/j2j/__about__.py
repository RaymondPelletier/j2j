# SPDX-FileCopyrightText: 2022-present RaymondPelletier <68929475+RaymondPelletier@users.noreply.github.com>
#
# SPDX-License-Identifier: MIT
__version__ = '0.0.1'
