import functools

from ..engine.opcodes import OpCode, Type
from .                import representation as jar

@functools.singledispatch
def emit(template, _):
    raise Exception(f'emit_template_opcodes could not handle {template}')

@emit.register(int)
@emit.register(float)
@emit.register(str)
@emit.register(bool)
@emit.register(type(None))
def _(template, _):
    yield OpCode.MATCH_VALUE, template

@emit.register(jar.Variable)
def _(template, bindings):
    identifier = template.identifier
    if identifier in bindings:
        yield OpCode.MATCH_VARIABLE, identifier
    else:
        yield OpCode.BIND_VARIABLE, identifier
        bindings |= {identifier}

@emit.register(jar.VarArgs)
def _(template, bindings):
    identifier = template.variable.identifier
    if identifier in bindings:
        yield OpCode.MATCH_VARARGS, identifier
    else:
        yield OpCode.BIND_VARARGS, identifier
        bindings |= {identifier}

@emit.register(dict)
def _(template, bindings):
    yield OpCode.ENSURE_TYPE, Type.DICT
    yield OpCode.MASK_DICT,

    kwargs = None
    for key, template in template.items():
        if type(key) == jar.KWArgs:
            kwargs = template
        else:
            yield OpCode.FOCUS_ON_KEY, key
            yield from emit(template, bindings)
            yield OpCode.POP_FOCUS,
        
    if kwargs is not None:
        yield from emit(kwargs, bindings)

@emit.register(list)
def _(template, bindings):
    yield OpCode.ENSURE_TYPE, Type.LIST,
    yield OpCode.MASK_LIST,
    for element in template:
        if isinstance(element, jar.VarArgs):
            yield from emit(element, bindings)
        else:
            yield OpCode.FOCUS_ON_HEAD,
            yield from emit(element, bindings)
            yield OpCode.POP_FOCUS,
    yield OpCode.MATCH_VALUE, []




def optimize_splats(instructions):
    splat = None
    for instruction in instructions:
        if splat is not None:
            if instruction == (OpCode.MATCH_VALUE, []):
                yield OpCode.BIND_VARIABLE, splat[1]
                splat = None
            else:
                yield splat
                splat = None
                if instruction[0] == OpCode.BIND_VARARGS: # lookahead would be useful
                    splat = instruction
                else:
                    yield instruction

        elif instruction[0] == OpCode.BIND_VARARGS:
            splat = instruction
        else:
            yield instruction

def emit_match(template):
    bindings = set()
    yield from optimize_splats(emit(template, bindings))
    yield OpCode.YIELD_BINDINGS,

def emit_collate(collate, initial_bindings):
    for matcher in collate:
        yield OpCode.FOCUS_ON_BINDING, matcher.variable.identifier
        yield from optimize_splats(emit(matcher.template, initial_bindings))
    for _ in collate:
        yield OpCode.POP_FOCUS, # Might need this later
    yield OpCode.YIELD_BINDINGS,
