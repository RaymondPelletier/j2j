import antlr4

from .  import representation as jar
from .  import helpers        as helpers
from .. import parser         as jp

class J2JBuilder(helpers.ASTBuilder, jp.Listener):

    def exitTransform(self, ctx):
        ctx.AST = jar.Transform(input=ctx.template(0).AST,
                                output=ctx.template(1).AST)

    def exitCollate(self, ctx):
        ctx.AST = self.ASTsOf(ctx.matcher())
    
    def exitJoin(self, ctx):
        ctx.AST = jar.Join(matchers=self.ASTsOf(ctx.matcher()),
                           assignments=self.ASTsOf(ctx.assignment()))

    def exitMatcher(self, ctx):
        ctx.AST = jar.Matcher(ctx.variable().AST, ctx.template().AST)

    def exitAssignment(self, ctx):
        ctx.AST = jar.Assignment(ctx.variable().AST, ctx.template().AST)

    def exitTemplate(self, ctx):
        ctx.AST = self.whichOf(ctx.obj(),
                               ctx.array(),
                               ctx.atom(),
                               ctx.variable()).AST

    def exitObj(self, ctx):
        ast = dict(self.ASTsOf(ctx.key_values))
        if ctx.kwargs() is not None:
            ast[jar.KWArgs()] = ctx.kwargs().AST
        ctx.AST = ast

    def exitKey_value(self, ctx):
        ctx.AST = (self.dequote(ctx.STRING().getText()), ctx.template().AST)

    def exitKwargs(self, ctx):
        ctx.AST = ctx.variable().AST

    def exitArray(self, ctx):
        ctx.AST = self.ASTsOf(ctx.elements)

    def exitElement(self, ctx):
        ctx.AST = self.whichOf(ctx.template(), ctx.varargs()).AST

    def exitVarargs(self, ctx):
        ctx.AST = jar.VarArgs(ctx.variable().AST)

    def exitAtom(self, ctx):
        if ctx.NULL() is not None:
            ctx.AST = None
        elif ctx.TRUE() is not None:
            ctx.AST = True
        elif ctx.FALSE() is not None:
            ctx.AST = False
        elif ctx.INTEGER() is not None:
            ctx.AST = int(ctx.INTEGER().getText())
        elif ctx.FLOAT() is not None:
            ctx.AST = float(ctx.FLOAT().getText())
        elif ctx.STRING() is not None:
            ctx.AST = self.dequote(ctx.STRING().getText())

    def exitVariable(self, ctx):
        ctx.AST = jar.Variable(ctx.IDENTIFIER().getText())

def string_parser(string):
    input_stream = antlr4.InputStream(string)
    lexer        = jp.Lexer(input_stream)
    token_stream = antlr4.CommonTokenStream(lexer)
    #
    return jp.Parser(token_stream)


def ast_for_string(string, rulename, trace=False):
    parser  = string_parser(string)
    builder = J2JBuilder(trace=trace)
    walker  = antlr4.ParseTreeWalker()
    rule    = getattr(parser, rulename)
    tree    = rule()
    #
    walker.walk(builder, tree)
    return tree.AST