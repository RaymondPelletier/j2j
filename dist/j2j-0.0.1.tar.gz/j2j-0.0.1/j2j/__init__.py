# SPDX-FileCopyrightText: 2022-present RaymondPelletier <68929475+RaymondPelletier@users.noreply.github.com>
#
# SPDX-License-Identifier: Apache-2.0

from .processors import Matcher, Filler, Transformer, Collator, Joiner

## Match
def match(template, target):
    return Matcher(template).match(target)

def match_all(template, target):
    yield from Matcher(template).match_all(target)

def compile_match(template):
    return Matcher(template)

## Fill
def fill(template, **bindings):
    return Filler(template).fill(**bindings)

def compile_fill(template):
    return Filler(template)

## Transform
def transform(template, source):
    return Transformer(template).transform(source)

def transform_all(template, source):
    yield from Transformer(template).transform_all(source)

def compile_transform(template):
    return Transformer(template)

## Collate
def collate(template, **targets):
    return Collator(template).collate(**targets)

def collate_all(template, **targets):
    yield from Collator(template).collate_all(**targets)

def compile_collate(template):
    return Collator(template)

## Join
def join(template, **targets):
    return Joiner(template).join(**targets)

def join_all(template, **targets):
    yield from Joiner(template).join_all(**targets)

def compile_join(template):
    return Joiner(template)

__all__ = ['match',     'match_all',     'compile_match', 
           'fill',                       'compile_fill',
           'transform', 'transform_all', 'compile_transform',
           'collate',   'collate_all',   'compile_collate',
           'join',      'join_all',      'compile_join']