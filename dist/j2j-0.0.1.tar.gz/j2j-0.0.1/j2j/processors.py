from re import T
import j2j.ast.emitter           as jae
import j2j.ast.builder           as jab

from   j2j.engine.interpreter    import Interpreter
from   j2j.engine.construct      import construct


class Bindings:
    def __init__(self, bindings):
        self._bindings = bindings

    @property
    def bindings(self):
        return {k: v for k, v in self._bindings.items() if not k.startswith('$')}

class Match(Bindings):
    def __init__(self, template, bindings):
        self._template = template
        super().__init__(bindings)

    @property
    def result(self):
        return construct(self._template, self._bindings)

class Matcher:
    def __init__(self, template):
        self._ast          = jab.ast_for_string(template, 'template')
        self._instructions = list(jae.emit_match(self._ast))

    def match_all(self, target):
        interpreter = Interpreter(self._instructions)
        for bindings in interpreter.match_all(target):
            yield Match(self._ast, bindings)

    def match(self, target):
        for m in self.match_all(target):
            return m


class Filler:
    def __init__(self, template):
        self._ast = jab.ast_for_string(template, 'template')

    def fill(self, **bindings):
        return construct(self._ast, bindings)


class Transformed(Bindings):
    def __init__(self, source, target, bindings):
        self._source   = source
        self._target   = target
        super().__init__(bindings)

    @property
    def source(self):
        return construct(self._source, self._bindings)

    @property
    def target(self):
        return construct(self._target, self._bindings)


class Transformer:
    def __init__(self, template):
        self._ast = jab.ast_for_string(template, 'transform')
        self._source = self._ast.input
        self._target = self._ast.output
        self._instructions = list(jae.emit_match(self._source))

    def transform_all(self, target):
        interpreter = Interpreter(self._instructions)
        for bindings in interpreter.match_all(target):
            yield Transformed(self._source, self._target, bindings)

    def transform(self, target):
        for m in self.match_all(target):
            return m.result



class Collation(Bindings):
    def __init__(self, templates, bindings):
        self._templates = templates
        super().__init__(bindings)
    
    @property
    def result(self):
        return {v: construct(t, self._bindings) for v, t in self._templates.items()}

class Collator:
    def __init__(self, template):
        self._ast = jab.ast_for_string(template, 'collate')
        self._toplevel = {m.variable.identifier for m in self._ast}
        self._instructions = list(jae.emit_collate(self._ast, self._toplevel))

    def collate_all(self, **targets):
        interpreter = Interpreter(self._instructions)
        for bindings in interpreter.match_all(None, targets):
            templates = {m.variable.identifier: m.template for m in self._ast}
            yield Collation(templates, bindings)

    def collate(self, **targets):
        for m in self.collate_all(**targets):
            return m.result



class Join(Bindings):
    def __init__(self, inputs, outputs, bindings):
        self._inputs   = inputs
        self._outputs  = outputs
        super().__init__(bindings)
    
    @property
    def result(self):
        return {v: construct(t, self._bindings) for v, t in self._outputs.items()}

class Joiner:
    def __init__(self, template):
        self._ast = jab.ast_for_string(template, 'join')
        self._toplevel = {m.variable.identifier for m in self._ast.matchers}
        self._instructions = list(jae.emit_collate(self._ast.matchers, self._toplevel))

    def join_all(self, **targets):
        interpreter = Interpreter(self._instructions)
        for bindings in interpreter.match_all(None, targets):
            inputs  = {m.variable.identifier: m.template for m in self._ast.matchers}
            outputs = {a.variable.identifier: a.template for a in self._ast.assignments}
            yield Join(inputs, outputs, bindings)

    def join(self, **targets):
        for m in self.join_all(targets):
            return m.result
