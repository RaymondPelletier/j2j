from . import J2JParser
from . import J2JLexer
from . import J2JListener

class Parser(J2JParser.J2JParser):
    pass

class Lexer(J2JLexer.J2JLexer):
    pass

class Listener(J2JListener.J2JListener):
    pass