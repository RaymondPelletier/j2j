import enum

class Type(enum.Enum):
    INT    = enum.auto()
    FLOAT  = enum.auto()
    STRING = enum.auto()
    BOOL   = enum.auto()
    NONE   = enum.auto()
    LIST   = enum.auto()
    DICT   = enum.auto()

    def __repr__(self):
        return self.name


class OpCode(enum.Enum):
    MATCH_VALUE      = enum.auto()
    MATCH_VARIABLE   = enum.auto()
    BIND_VARIABLE    = enum.auto()

    ENSURE_TYPE      = enum.auto()

    BIND_VARARGS     = enum.auto()
    MATCH_VARARGS    = enum.auto()

    MASK_LIST        = enum.auto()
    MASK_DICT        = enum.auto()
    
    FOCUS_ON_HEAD    = enum.auto()
    FOCUS_ON_KEY     = enum.auto()
    FOCUS_ON_BINDING = enum.auto()


    POP_FOCUS        = enum.auto()
    YIELD_BINDINGS   = enum.auto()

    def __repr__(self):
        return self.name